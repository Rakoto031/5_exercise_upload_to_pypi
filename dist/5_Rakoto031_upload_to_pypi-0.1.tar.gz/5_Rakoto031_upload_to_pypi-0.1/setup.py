from setuptools import setup

setup(name='5_Rakoto031_upload_to_pypi',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['5_Rakoto031_upload_to_pypi'],
      zip_safe=False)
